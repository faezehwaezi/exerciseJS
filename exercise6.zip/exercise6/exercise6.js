// 1- DOM Selection & Logging
// Select the first <div> element on the page and log it.
console.log(document.querySelector('div'));

// Select all <div> elements and log the second one.
console.log(document.querySelectorAll('div')[1]);

// Select an element with the class "divf" and log its inner HTML.
let selectdiv = document.querySelectorAll('div')[1].classList.add("divf");
console.log(document.body.getElementsByClassName("divf")[0].innerHTML);

// Select an element with the id="idSecond" and log its inner text.
console.log(document.getElementById("thirdid").innerHTML);





// 2. Modifying the DOM
// Select a specific <div> and change its innerText to "Changed Content!".
document.getElementById("thirdid").innerText = "HELLO.HELLO!!!!";

// Create a new <p> element, set its text to "This is a new paragraph", and append it to the second <div> on the page.
let maindiv = document.body.getElementsByClassName('divf')[0];
let newp = document.createElement('p');
newp.textContent = "This is a new paragraph" ;
maindiv.appendChild(newp);

// Create a new <div> with inner HTML containing:
// <h2>Title</h2>
// <p>Some content inside the div</p>
// and append it to the <body>.
let lastdiv = document.createElement('div');
lastdiv.innerHTML = "<h2>Title</h2>  <p>Some content inside the div</p>";
document.body.append(lastdiv);
console.log(lastdiv);





// 4. Removing Elements
// Select an existing <div> and remove its last child element.
let reomovid = document.getElementById('thirdid');
if (reomovid.lastElementChild){
    reomovid.removeChild(reomovid.lastElementChild);
}
// Select another element and completely remove it from the page.
console.log(maindiv);
maindiv.remove();





// 5. Section Manipulation
// Select a section with class "sectionF".
let newsec = document.createElement('section');
document.body.append(newsec);
newsec.classList.add("sectionF");
console.log(newsec);

// Create a new <div> inside this section with inner HTML containing:
{/* <p>HTML</p>
<p>CSS</p>
<p>JavaScript</p> */}
let divf = document.createElement('div');
divf.innerHTML = "<p>HTML</p><p>CSS</p><p>JavaScript</p>";
newsec.append(divf);
console.log(newsec);
// Log the text of the first child inside "sectionF".
if(newsec.firstChild){
    console.log((newsec.firstChild).innerText)
}
// Remove all child elements inside "sectionF" using a while loop.
while(newsec.firstChild){
    (newsec.firstChild).remove()
}
console.log(newsec);




// Bonus Challenge:
// Create a button that, when clicked, adds a new <p> element with "New Paragraph added!" inside a div.
document.addEventListener("DOMContentLoaded" , function(){

    let btndomm = document.body.getElementsByClassName('btndom')[0];

    let btnp = document.createElement('p');
    btnp.textContent = "New Paragraph added!"
    document.body.appendChild(btnp);
    btnp.style.display = "none";
    btndomm.addEventListener("click" , function(){
        btnp.style.display = "block";
});
});

// Add an event listener to remove any paragraph inside a specific div when clicked.
document.addEventListener("DOMContentLoaded" , function(){

    let btndomm = document.body.getElementsByClassName('btndom')[0];

    btndomm.addEventListener("click" , function(){
        
    let firstdiv = document.querySelectorAll('div')[0];
    firstdiv.remove();
});
});







